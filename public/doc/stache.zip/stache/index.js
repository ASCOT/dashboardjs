module.exports = require('./lib/stache');
